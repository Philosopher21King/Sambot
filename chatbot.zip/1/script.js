     // JavaScript for the chatbot
        document.addEventListener('DOMContentLoaded', function() {
            const chatMessages = document.getElementById('chat-messages');
            const userInput = document.getElementById('user-input');
            const sendButton = document.getElementById('send-button');
            const typingIndicator = document.getElementById('typing-indicator');
            
            // Function to add a message to the chat
            function addMessage(message, isUser) {
                const messageDiv = document.createElement('div');
                messageDiv.classList.add('message');
                messageDiv.classList.add(isUser ? 'user-message' : 'bot-message');
                messageDiv.textContent = message;
                chatMessages.appendChild(messageDiv);
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
            
            // Function to simulate bot thinking
            function showTypingIndicator() {
                typingIndicator.style.display = 'block';
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
            
            function hideTypingIndicator() {
                typingIndicator.style.display = 'none';
            }
            
            // Function to process user input and generate bot response
            function processUserInput() {
                const message = userInput.value.trim();
                if (message === '') return;
                
                // Add user message to chat
                addMessage(message, true);
                userInput.value = '';
                
                // Show typing indicator
                showTypingIndicator();
                
                // Simulate bot thinking (delay before response)
                setTimeout(() => {
                    hideTypingIndicator();
                    const botResponse = generateBotResponse(message);
                    addMessage(botResponse, false);
                }, 1000 + Math.random() * 2000); // Random delay between 1-3 seconds
            }
            
            // Simple response generation
            function generateBotResponse(userMessage) {
                const lowerMessage = userMessage.toLowerCase();
                
                if (lowerMessage.includes('hello') || lowerMessage.includes('hi')) {
                    return "Hello there! How can I assist you today?";
                } else if (lowerMessage.includes('how are you')) {
                    return "I'm just a chatbot, but I'm functioning well! How about you?";
                } else if (lowerMessage.includes('bye') || lowerMessage.includes('goodbye')) {
                    return "Goodbye! Feel free to come back if you have more questions.";
                } else if (lowerMessage.includes('thank')) {
                    return "You're welcome! Is there anything else I can help with?";
                } else if (lowerMessage.includes('help')) {
                    return "I can answer simple questions. Try asking me about my capabilities or just say hello!";
                } else if (lowerMessage.includes('name')) {
                    return "I'm just CIA bot. welcome!";
                } else if (lowerMessage.includes('time')) {
                    return "I don't have access to the current time, but you can check your device's clock.";
                } else if (lowerMessage.includes('weather')) {
                    return "I'm not connected to weather services, but you can check a weather website or app.";
                } else {
                    const randomResponses = [
                        "I'm not sure I understand. Can you rephrase that?",
                        "That's interesting. Tell me more.",
                        "I'm still learning. Could you ask me something else?",
                        "I don't have information about that topic.",
                        "Thanks for sharing that with me!"
                    ];
                    return randomResponses[Math.floor(Math.random() * randomResponses.length)];
                }
            }
            
            // Event listeners
            sendButton.addEventListener('click', processUserInput);
            
            userInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    processUserInput();
                }
            });
        });